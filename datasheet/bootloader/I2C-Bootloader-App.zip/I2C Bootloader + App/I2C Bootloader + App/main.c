/*
 * I2C Bootloader + App.c
 *
 * Created: 28-Oct-19 16:10:48
 * Author : M52422
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

