/******************************************************************************
 * © 2018 Microchip Technology Inc. and its subsidiaries.
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
 * IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR
 * EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED,
 * EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 *
 *****************************************************************************/

/*
 * Application example for Bootloader for tinyAVR 0- and 1-series, and megaAVR 0-series
 *
 * To make sure the code is correctly compiled it is necessary to configure the start
 * of this application code in Toolchain->AVR/GNU Linker->Memory Settings.
 * If the BOOTEND fuse is 0x01 then the boot section is 0x01*0x80 words, so set .text=0x80
 */
#define F_CPU (20E6)

#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	/* Configure clock to 20MHz */
	_PROTECTED_WRITE(CLKCTRL_MCLKCTRLB, 0);

	/* Toggle LED */
	PORTB.DIRSET = PIN4_bm;
	while(1) {
		PORTB.OUTTGL = PIN4_bm;
		_delay_ms(250);
	}
}

